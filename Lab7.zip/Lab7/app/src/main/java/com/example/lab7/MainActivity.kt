package com.example.lab7

import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// 記得引入這行 (你的 package name + databinding + ActivityMainBinding)
import com.example.lab7.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // 1. 使用 ViewBinding 取代 findViewById
    // lateinit 代表「我保證稍後會初始化它，現在先別報錯」
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 2. 初始化 Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        // 使用 binding.root 作為畫面內容
        setContentView(binding.root)

        setupWindowInsets()
        setupViews()
    }

    // 3. 將視窗邊界設定抽離成獨立函式，保持 onCreate 乾淨
    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // 4. 主要的 UI 設定邏輯
    private fun setupViews() {
        // 呼叫產生資料的函式
        val (counts, items) = generateMockData()

        // --- 設定 Spinner ---
        // 直接用 binding.spinner，不用再 findViewById
        binding.spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            counts
        )

        // --- 設定 GridView ---
        binding.gridView.apply {
            numColumns = 3
            adapter = MyAdapter(this@MainActivity, items, R.layout.adapter_vertical)
        }

        // --- 設定 ListView ---
        binding.listView.adapter = MyAdapter(this, items, R.layout.adapter_horizontal)
    }

    // 5. 將「產生假資料」的邏輯完全抽離
    // 回傳一個 Pair (數量列表, 商品列表)
    private fun generateMockData(): Pair<List<String>, List<Item>> {
        val countList = mutableListOf<String>()
        val itemList = mutableListOf<Item>()

        // 讀取圖檔資源
        val array = resources.obtainTypedArray(R.array.image_list)

        // 使用 try-finally 區塊確保資源一定會被釋放 (防呆)
        try {
            for (index in 0 until array.length()) {
                val photoId = array.getResourceId(index, 0)
                // 字串模板優化
                val name = "水果${index + 1}"
                // Kotlin Range 直接取亂數
                val price = (10..100).random()

                countList.add("${index + 1}個")
                itemList.add(Item(photoId, name, price))
            }
        } finally {
            // 6. 確保即使發生錯誤，圖檔資源也會被回收
            array.recycle()
        }

        return Pair(countList, itemList)
    }
}