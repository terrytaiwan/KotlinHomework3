package com.example.lab7

import android.os.Parcelable
import androidx.annotation.DrawableRes
import kotlinx.parcelize.Parcelize

// 1. 加入 @Parcelize 註解並實作 Parcelable
@Parcelize
data class Item(
    // 2. 加入 @DrawableRes 註解限制輸入內容
    @DrawableRes val photo: Int,
    val name: String,
    val price: Int
) : Parcelable {

    // 3. 增加輔助屬性，把顯示邏輯封裝起來
    val priceText: String
        get() = "$price 元"
}