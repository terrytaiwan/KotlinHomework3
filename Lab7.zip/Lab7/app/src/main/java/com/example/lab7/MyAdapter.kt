package com.example.lab7

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class MyAdapter(
    context: Context,
    data: List<Item>,
    private val layout: Int
) : ArrayAdapter<Item>(context, layout, data) {

    // 1. 定義一個 ViewHolder 類別來暫存元件
    // 這樣就不用每次都 findViewById
    private class ViewHolder(view: View) {
        val imgPhoto: ImageView = view.findViewById(R.id.imgPhoto)
        val tvMsg: TextView = view.findViewById(R.id.tvMsg)
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View
        val holder: ViewHolder

        // 2. 判斷是否已經有舊畫面 (Recycling)
        if (convertView == null) {
            // 如果沒有舊畫面，就建立新的
            view = LayoutInflater.from(context).inflate(layout, parent, false)
            // 建立 ViewHolder 並連結元件
            holder = ViewHolder(view)
            // 將 holder 藏在 view 的標籤 (tag) 裡，方便下次取用
            view.tag = holder
        } else {
            // 如果有舊畫面，直接拿來用
            view = convertView
            // 從標籤裡把之前存好的 holder 拿出來
            holder = view.tag as ViewHolder
        }

        // 3. 綁定資料 (這裡只負責設定內容，不用再找元件了)
        val item = getItem(position) ?: return view

        holder.imgPhoto.setImageResource(item.photo)

        holder.tvMsg.text = if (layout == R.layout.adapter_vertical) {
            item.name
        } else {
            "${item.name}: ${item.price}元"
        }

        return view
    }
}