package com.example.lab8

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// 記得引入 Binding
import com.example.lab8.databinding.ActivitySecBinding

class SecActivity : AppCompatActivity() {

    // 1. 使用 ViewBinding
    private lateinit var binding: ActivitySecBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 初始化 ViewBinding
        binding = ActivitySecBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWindowInsets()
        setupListeners()
    }

    // 抽離視窗邊界設定
    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // 抽離按鈕監聽邏輯
    private fun setupListeners() {
        binding.btnSend.setOnClickListener {
            // 先取出文字，並去除頭尾空白 (trim) 避免使用者只按空白鍵
            val name = binding.edName.text.toString().trim()
            val phone = binding.edPhone.text.toString().trim()

            // 2. 驗證邏輯
            when {
                name.isEmpty() -> showToast("請輸入姓名")
                phone.isEmpty() -> showToast("請輸入電話")
                else -> {
                    // 驗證通過，回傳資料
                    returnResult(name, phone)
                }
            }
        }
    }

    // 3. 處理回傳邏輯
    private fun returnResult(name: String, phone: String) {
        // 不需要特地建立 Bundle，直接 Intent putExtra 比較簡潔
        val intent = Intent().apply {
            putExtra("name", name)
            putExtra("phone", phone)
        }
        setResult(Activity.RESULT_OK, intent)
        finish() // 結束這個 Activity，回到上一頁
    }

    // 顯示 Toast 的輔助函式
    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}