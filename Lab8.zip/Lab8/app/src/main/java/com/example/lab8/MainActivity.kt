package com.example.lab8

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
// 記得確認 build.gradle 有開啟 viewBinding
import com.example.lab8.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // 1. 使用 ViewBinding
    private lateinit var binding: ActivityMainBinding
    private lateinit var myAdapter: MyAdapter
    private val contacts = ArrayList<Contact>()

    // 2. 優化回傳結果處理
    private val startForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let { intent ->
                val name = intent.getStringExtra("name") ?: ""
                val phone = intent.getStringExtra("phone") ?: ""

                // 防呆：確保有資料才新增
                if (name.isNotEmpty() && phone.isNotEmpty()) {
                    val newContact = Contact(name, phone)
                    contacts.add(newContact)

                    // 3. 關鍵優化：只更新新增的那一筆，會有漂亮的插入動畫
                    myAdapter.notifyItemInserted(contacts.size - 1)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 初始化 Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWindowInsets()
        setupRecyclerView()
        setupListeners()
    }

    // 將邊界設定抽離，保持 onCreate 乾淨
    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // 集中管理 RecyclerView 設定
    private fun setupRecyclerView() {
        myAdapter = MyAdapter(contacts)

        // 使用 apply 語法糖，程式碼更易讀
        binding.recyclerView.apply {
            // LinearLayoutManager 預設就是 VERTICAL，可以省略不寫
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = myAdapter
        }
    }

    // 集中管理按鈕監聽
    private fun setupListeners() {
        binding.btnAdd.setOnClickListener {
            val intent = Intent(this, SecActivity::class.java)
            startForResult.launch(intent)
        }
    }
}