package com.example.lab8

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// 1. 加入 Parcelable，讓聯絡人資料可以在頁面間傳送 (例如點擊後跳轉到詳細頁)
@Parcelize
data class Contact(
    val name: String,

    // 2. 保持用 String 存電話 (這是對的！)
    // 千萬不要用 Int，不然開頭的 0 會不見 (0912 -> 912)
    val phone: String
) : Parcelable {

    // 3. 增加一個輔助屬性，方便 Adapter 顯示
    // 這樣在 Adapter 裡就不用寫 "${item.name} (${item.phone})" 這種醜醜的程式碼
    val label: String
        get() = "$name ($phone)"
}
