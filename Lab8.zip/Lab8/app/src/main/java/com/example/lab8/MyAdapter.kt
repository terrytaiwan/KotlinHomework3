package com.example.lab8

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
// 記得引入 ViewBinding (你的 layout 檔名是 adapter_row.xml，所以是 AdapterRowBinding)
import com.example.lab8.databinding.AdapterRowBinding

class MyAdapter(
    // 改用 MutableList 比較通用，雖然 ArrayList 也可以
    private val data: ArrayList<Contact>
) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    // 1. 使用 ViewBinding 修改 ViewHolder
    // 這樣就不用在裡面寫一堆 findViewById
    class ViewHolder(val binding: AdapterRowBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: Contact) {
            binding.tvName.text = item.name
            binding.tvPhone.text = item.phone
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // 2. 使用 ViewBinding 建立畫面
        val binding = AdapterRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // 綁定資料顯示
        holder.bind(data[position])

        // 3. 設定刪除按鈕的監聽器
        holder.binding.imgDelete.setOnClickListener {
            // 關鍵優化：取得「目前真正的」位置
            // 因為刪除後 position 會變動，bindingAdapterPosition 才是當下最準的
            // 改用 adapterPosition (雖然會顯示刪除線/被棄用，但在舊版本這是唯一解法)
            val actualPosition = holder.adapterPosition

            // 防呆：確保位置有效
            if (actualPosition != RecyclerView.NO_POSITION) {
                // A. 移除資料
                data.removeAt(actualPosition)

                // B. 通知 Adapter 這一項被移除了 (觸發刪除動畫！)
                notifyItemRemoved(actualPosition)

                // C. 通知 Adapter 檢查受影響的範圍 (讓下面的項目位置編號更新)
                // 這行能確保連續刪除時不會刪錯人
                notifyItemRangeChanged(actualPosition, data.size)
            }
        }
    }
}